<template>
	<view class="content">
		<view class="top">
			<!-- 头部标题框 -->
			<uni-nav-bar shadow="false" border="false" height="60rpx" style="width: 100%;" leftWidth="54rpx"
				rightWidth="54rpx" backgroundColor="#f2f2f2">
				<!-- 左侧商标 -->
				<view slot="left" style="width: 50rpx;height: 60rpx;line-height: 60rpx;">
					<image src="../../static/image/xiaomi.png" mode="" style="width:50rpx;height:32rpx;"></image>
				</view>
				<!-- 中间搜索框 -->
				<input placeholder="例如:苹果" @click="change"
					style="padding: 0;width:calc(100vw - 108rpx);height: 60rpx; padding-left: 60rpx;border: 1px solid #e5e5e5;background-color: #fff;">
				<uni-icons type="search" size="25" style="position: absolute;height: 60rpx; line-height: 60rpx;">
				</uni-icons>
				</input>
				<!-- 右侧我的图标 -->
				<view slot="right" style="width: 50rpx;height: 60rpx;line-height: 60rpx;text-align: center;">
					<uni-icons type="person" size="28" @click="toUser"></uni-icons>
				</view>
			</uni-nav-bar>
			<!-- 分类导航 -->
			<scroll-view class="tarBanner" scroll-x :scroll-into-view="scrollInto">
				<view class="bar" v-for="(item, index) in tabBars" :key="index" :id="'tab-'+index"
					:class="{active: tabIndex === index}" @click="changeTab(index)">
					<text class="font-item1" :class="{line:tabIndex===index}">{{item.name}}</text>
				</view>
			</scroll-view>
		</view>
		<!-- 导航内容 -->
		<swiper :duration="500" :current="tabIndex" class="section">
			<swiper-item class="showSection" v-for="(item,index) in pageItems" :key="index">
				<!-- 推荐页 -->
				<template class="mainSection" v-if="item.type==='recommend'">
					<!-- 轮播图 -->
					<swiper class="photos" :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000"
						:circular="true">
						<swiper-item v-for="(obj,index) in item.swiperImage" :key="index">
							<image :src="obj.src" mode="" class="swiper-image"></image>
						</swiper-item>
					</swiper>
					<!-- 分类导航 -->
					<uni-grid :column="2" class="kinds">
						<view class="" v-for="(icon,index) in item.swiperIcons" :key="index">
							<image :src="icon.src" mode="" class="swiper-icon" @click="iconTo(icon.text)"></image>
						</view>
					</uni-grid>
					<!-- 商品展示 -->
					<view class="showGoods">
						<view class="left">
							<image src="../../static/goods/goods1.webp" mode=""></image>
						</view>
						<view class="right">
							<view class="top">
								<image src="../../static/goods/goods2.webp" mode=""></image>
							</view>
							<view class="buttom">
								<image src="../../static/goods/goods3.webp" mode=""></image>
							</view>
						</view>
					</view>
					<!-- 热销爆款 -->
					<view class="hotGoods">
						<image src="../../static/image/hotGood.webp" mode=""></image>
					</view>
					<!-- 商品列表 -->
					<good-list :goodsListImage="item.goodsListImage" @goodsListOn="goodsListClick"></good-list>
				</template>
				<!-- 手机页 -->
				<template v-else-if="item.type==='phone'">
					<view>{{item.data.text}}</view>
				</template>
				<!-- 智能页 -->
				<template v-else-if="item.type==='Al'">
					<view>{{item.data.text}}</view>
				</template>
				<template v-else>
					<view>暂无数据</view>
				</template>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
	import goodList from "../../components/goodsList/goodsList.vue";

	const response = {
		"data": {
			"page1": {
				"type": "recommend",
				"swiperImage": [{
					"src": "../../static/swiper-images/swiper1.jpg"
				}, {
					"src": "../../static/swiper-images/swiper2.jpg"
				}, {
					"src": "../../static/swiper-images/swiper3.jpg"
				}],
				"swiperIcons": [{
						"src": "../../static/swiper-icons/swiper-icons1.webp",
						"text": "米金商城"
					},
					{
						"src": "../../static/swiper-icons/swiper-icons2.webp",
						"text": "小米众筹"
					},
					{
						"src": "../../static/swiper-icons/swiper-icons3.webp",
						"text": "手机"
					},
					{
						"src": "../../static/swiper-icons/swiper-icons4.webp",
						"text": "以旧换新"
					},
					{
						"src": "../../static/swiper-icons/swiper-icons5.webp",
						"text": "小米上新"
					},
					{
						"src": "../../static/swiper-icons/swiper-icons6.webp",
						"text": "智能"
					},
					{
						"src": "../../static/swiper-icons/swiper-icons7.webp",
						"text": "笔记本热卖"
					},
					{
						"src": "../../static/swiper-icons/swiper-icons8.webp",
						"text": "电视热卖"
					},
					{
						"src": "../../static/swiper-icons/swiper-icons9.webp",
						"text": "洗衣机热卖"
					},
					{
						"src": "../../static/swiper-icons/swiper-icons10.webp",
						"text": "米粉卡"
					}
				],
				"goodsListImage": [{
						"id": 0,
						"src": "../../static/goodsList-images/goodsList-image1.jpg",
						"title": "Xiaomi 11 Pro",
						"attribute": "1/1.2 GN2 | 骁龙888",
						"sale": 3399,
						"price": "￥4999",

					},
					{
						"id": 1,
						"src": "../../static/goodsList-images/goodsList-image2.jpg",
						"title": "Xiaomi MIX FOLD折叠屏手机",
						"attribute": "折叠大屏｜自研芯片",
						"sale": 6999,
						"price": "￥7999",

					},
					{
						"id": 2,
						"src": "../../static/goodsList-images/goodsList-image3.jpg",
						"title": "Note 9 5G",
						"attribute": "天玑 800U处理器",
						"sale": 1149,
						"price": "￥1299",

					},
					{
						"id": 3,
						"src": "../../static/goodsList-images/goodsList-image4.jpg",
						"title": "Xiaomi 10S",
						"attribute": "骁龙870 | 对称式双扬立体声",
						"sale": 2699,
						"price": "",

					},
					{
						"id": 4,
						"src": "../../static/goodsList-images/goodsList-image5.jpg",
						"title": "Note 9 Pro 5G",
						"attribute": "一亿像素夜景相机",
						"sale": 1399,
						"price": "￥1599",

					},
					{
						"id": 5,
						"src": "../../static/goodsList-images/goodsList-image6.jpg",
						"title": "Xiaomi 11",
						"attribute": "骁龙888 | 2K四曲面屏",
						"sale": 2999,
						"price": "￥3799",

					},
					{
						"id": 6,
						"src": "../../static/goodsList-images/goodsList-image7.jpg",
						"title": "黑鲨4",
						"attribute": "磁动力升降肩键",
						"sale": 2499,
						"price": "￥4999",

					},
					{
						"id": 7,
						"src": "../../static/goodsList-images/goodsList-image8.jpg",
						"title": "Redmi  K40 Pro 系列",
						"attribute": "骁龙888 / E4 旗舰直屏",
						"sale": 2499,
						"price": "2799",

					}
				]
			},
			"page2": {
				"type": "phone",
				"data": {
					"id": 0,
					"text": '手机',
				}
			},
			"page3": {
				"type": "Al",
				"data": {
					"id": 0,
					"text": '智能',
				}
			},
			"page4": {
				"type": ""
			},
			"page5": {
				"type": ""
			},
			"page6": {
				"type": ""
			},
			"page7": {
				"type": ""
			},
		}
	}

	export default {

		data() {
			return {
				title: 'Hello',
				scrollInto: '',
				// 分类数组
				tabBars: [{
					"id": 1,
					"name": "推荐",
					"order": 50,
					"template": "index"
				}, {
					"id": 2,
					"name": "手机",
					"order": 50,
					"template": "special"
				}, {
					"id": 3,
					"name": "智能",
					"order": 50,
					"template": "special"
				}, {
					"id": 4,
					"name": "电视",
					"order": 50,
					"template": "special"
				}, {
					"id": 5,
					"name": "笔记本",
					"order": 50,
					"template": "special"
				}, {
					"id": 6,
					"name": "家电",
					"order": 50,
					"template": "special"
				}, {
					"id": 7,
					"name": "生活周边",
					"order": 50,
					"template": "special"
				}, ],
				//
				tabIndex: 0,
				//
				pageItems: [],
				//
				scrollHeight: 0
			}
		},
		onLoad() {
			this.pageItems = response.data;
		},
		methods: {
			toUser() {
				console.log("ds")
				uni.switchTab({
					url: '../user/user'
				})
			},
			change() {
				uni.navigateTo({
					url: '../search/search'
				})
			},
			changeTab(index) {
				if (this.index === index) {
					return;
				}
				this.tabIndex = index;
				this.scrollInto = 'tab-' + index;
				// 下方tab-content 中的数据加载
			},
			iconTo(value) {
				console.log(value)
			},
			goodsListClick(id) {
				console.log("index", id)
			}
		},
		components: {
			goodList
		}
	}
</script>

<style>
	* {
		margin: 0;
		padding: 0;
	}

	.tarBanner {
		height: 64rpx;
		white-space: nowrap;
		background-color: #f2f2f2;
	}

	.active {
		color: #fc6858;
	}

	.bar {
		display: inline-block;
		height: 60rpx;
		line-height: 60rpx;
		width: 150rpx;
		text-align: center;
	}

	.font-item1 {
		font-size: 36rpx;
	}

	.line {
		padding-bottom: 4rpx;
		border-bottom: 4rpx solid #FC6858;
	}

	.section {
		display: block;
		width: 100vw;
		height: calc(100vh - 226rpx);
		overflow: auto;
	}

	.showSection {
		display: block;
		width: 100vw;
		height: calc(100vh - 226rpx);
		overflow: auto;
	}

	.mainSection {
		display: block;
		width: 100vw;
		height: calc(100vh - 226rpx);
		overflow: auto;
	}

	.photos {
		width: 100vw;
		height: 375rpx;
	}

	.swiper-image {
		width: 100vw;
		height: 375rpx;

	}

	.kinds {
		width: 100vw;
		height: 300rpx;
	}

	.swiper-icon {
		width: 18vw;
		height: 150rpx;
		margin: 0 .8vw;
	}

	.showGoods {
		height: 520rpx;
		width: 100vw;
		margin: 10rpx 0;
	}

	.left {
		display: inline-block;
		height: 520rpx;
		width: 50vw;
		margin-right: 1vw;
	}

	.left image {
		height: 520rpx;
		width: 50vw;
	}

	.right {
		display: inline-block;
		height: 260rpx;
		width: 49vw;
	}

	.right .top {
		width: 49vw;
		height: 260rpx;
	}

	.right .top image {
		width: 49vw;
		height: 256rpx;

	}

	.right .buttom {
		width: 49vw;
		height: 260rpx;
	}

	.right .buttom image {
		width: 49vw;
		height: 256rpx;
	}

	.hotGoods,
	.hotGoods image {
		width: 100vw;
		height: 460rpx;
	}
</style>
