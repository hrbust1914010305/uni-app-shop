<template>
	<view class="goodsList">
		<uni-group>
			<view class="goodsItem" v-for="item in goodsListImage" :key="item.id" @click="goTo(item.id)">
				<image :src="item.src" mode=""></image>
				<text style="font-size: 30rpx;height: 32rpx;text-align: center;">
					{{item.title}}</text>
				<text style="font-size: 28rpx;height: 30rpx;text-align: center;">{{item.attribute}}</text>
				<text style="font-size: 30rpx;height: 42rpx;text-align: center;color: #EA625B;">￥{{item.sale}} 起
					<span
						style="color: #000000;font-size: 24rpx;display: inline-block;margin-left: 8rpx;text-decoration: line-through;">{{item.price}}</span></text>
				<button class="buyButton" type="warn">立即购买</button>
			</view>
		</uni-group>
	</view>
</template>

<script>
	export default {
		name: "goodsList",
		props: ['goodsListImage'],
		data() {
			return {

			};
		},
		methods: {
			goTo(value) {
				this.$emit("goodsListOn", value);
			}
		}
	}
</script>

<style>
	/deep/ .uni-group__content {
		padding: 0;
	}

	.goodsItem {
		height: 510rpx;
		width: 49vw;
		display: inline-block;
		margin: 10rpx .5vw;
	}

	.goodsItem image {
		height: 290rpx;
		width: 49vw;
	}

	.goodsItem text {
		display: inline-block;
		width: 49vw;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.goodsItem text span {
		text-align: center;
	}

	.buyButton {
		width: 30vw;
		margin: 0 auto;
	}
</style>
