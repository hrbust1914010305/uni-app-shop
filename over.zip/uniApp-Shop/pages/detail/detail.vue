<template>
	<view class="datail">
		<!-- 顶部搜索框 -->
		<uni-nav-bar leftIcon="left" rightIcon="upload" backgroundColor="rgba(0,0,0,.1)"
			style="position: fixed;z-index: 9;width: 100vw;" @clickLeft="back"></uni-nav-bar>
		<!-- 轮播图 -->
		<view class="swiper-wrap">
			<swiper :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000" circular="true"
				@change="changeSwiper" indicator-dots="false" style="width: 100vw;height: 824rpx;">
				<swiper-item style="width: 100vw;height: 824rpx;" v-for="(item,index) in data.swiperImages"
					:key="index">
					<image :src="item.src" mode="" style="width: 100vw;height: 824rpx;"></image>
				</swiper-item>
			</swiper>
			<!-- 定位 -->
			<view style="width: 100rpx;height: 40rpx;background-color: rgba(0,0,0,.3);
			border-radius: 50rpx;line-height: 40rpx;text-align: center;position: absolute;right: 20rpx;top: 740rpx;">
				{{current}}/{{data.swiperImages.length}}
			</view>
		</view>
		<!-- 价格 -->
		<text style="color: #FC6858;display: block;width: 96vw;height: 80rpx;margin-left: 40rpx;font-size: 50rpx;">￥1599
			<span style="font-size: 25rpx;text-decoration: line-through;color: #000000;">￥1799</span></text>
		<!-- 描述 -->
		<view class="describe">
			<view>
				<view style="font-size: 32rpx;margin:10rpx 0 10rpx 20rpx ;height: 40rpx;line-height: 40rpx;">
					{{data.describe.title}}
				</view>
				<view style="font-size: 25rpx;margin:10rpx 0 10rpx 40rpx ;height: 30rpx;line-height: 30rpx;">
					{{data.describe.smallTitle}}
				</view>
				<view>
					<uni-list v-for="(date,index) in data.describe.data" :key="date.id"
						style="font-size: 25rpx;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">
						<uni-list-item :title="date.text"></uni-list-item>
					</uni-list>
				</view>
			</view>
		</view>
		<!-- 配置 -->
		<scroll-view scroll-x :scroll-into-view="scrollInto" style="width: 100vw;height: 176rpx;white-space: nowrap;"
			@click="open">
			<view style="height: 176rpx;width: 176rpx;display: inline-block;margin: 0 6rpx;background-color: #eee;"
				v-for="(item,index) in data.icons" :key="index">
				<view
					style="width: 40rpx;height: 40rpx;position: relative;top: 20rpx;left: 50%;transform: translateX(-50%);display: inline-block;">
					<image :src="item.src" mode="" style="width: 40rpx;height: 40rpx;">
					</image>
				</view>
				<text
					style="display: block;height: 50rpx;line-height: 50rpx;text-align: center;position: relative;top: 24rpx;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;font-size: 25rpx;">{{item.name}}</text>
				<text
					style="display: block;height: 50rpx;line-height: 50rpx;text-align: center;position: relative;top: 24rpx;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;font-size: 24rpx;">{{item.text}}</text>
			</view>
		</scroll-view>
		<!-- 底部弹窗 -->
		<uni-popup ref="popup" background-color="rgba(0,0,0,0)">
			<view class=""
				style="width: 100vw;height: 1084rpx;background-color: #fff; border-top-right-radius: 40rpx; border-top-left-radius: 40rpx;">
				<view class="" style="height: 100rpx;width: 680rpx;margin: 0 auto;">
					<view class="" style="line-height: 100rpx;text-align: center;width: 640rpx;display: inline-block;">
						关键参数
					</view>
					<uni-icons type="closeempty" size="20" @click="close"></uni-icons>
				</view>
				<!-- 数据列表 -->
				<view style="height: 820rpx;width: 680rpx;margin: 0 auto;overflow: auto;">
					<view class="" style="height: 120rpx;width: 680rpx;line-height: 80rpx;"
						v-for="(item,index) in data.icons" :key="index">
						<view style="height: 120rpx;width: 220rpx;line-height: 80rpx;display: inline-block;
						white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">
							{{item.name}}
						</view>
						<view style="height: 120rpx;width: 430rpx;line-height: 80rpx;display: inline-block;margin-left: 20rpx;
						white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">
							{{item.text}}
						</view>
					</view>
					<view class="" style="background-color: #fff;position: fixed;bottom: 0;width: 100vw;border: none;left: 0;">
						<button type="default" style="background-color: #ff6700;border-radius: 50rpx;"
							@click="close">确定</button>
					</view>
				</view>
			</view>
		</uni-popup>
		<!-- 已选 -->
		<view class="" style="width: 100vw;height: 90rpx;" @click="open2()">
			<text style="width: 90rpx;height: 90rpx;line-height: 90rpx;display: inline-block;
			position: relative;top: -30rpx;left: 20rpx;">
				已选</text><text style="height: 90rpx;display: inline-block;width: calc(100vw - 150rpx);margin-left: 20rpx;">{{goodMessage2}}</text><text style="float: right;height: 90rpx;line-height: 90rpx;">></text>
		</view>
		<!-- 弹出层 -->
		<uni-popup ref="popup2" background-color="rgba(0,0,0,0)">
			<view class=""
				style="width: 100vw;height: 1076rpx;background-color: #fff; border-top-right-radius: 40rpx; border-top-left-radius: 40rpx;">
				<view class="" style="height: 100rpx;width: 680rpx;margin: 0 auto;">
					<!-- 主体 -->
					<view class="" style="width: 90vw;height: 1076rpx;margin: 0 auto;">
						<!-- 展示 -->
						<view class="" style="width: 100%;height: 180rpx;">
							<view class="" style="display: inline-block;width: 160rpx;">
								<image
									src="https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/aca0b2da7c6f2d4f00179cddb6b478ec.png"
									mode="" style="width: 160rpx;height: 160rpx;"></image>
							</view>
							<text style="display: inline-block;line-height: 80rpx;position: absolute;
							top: 20rpx;left: 200rpx;color: #ff5934;font-size: 50rpx;
							">￥1699 <span style="font-size: 25rpx; color: #000000;text-decoration: line-through;">￥1799</span></text>
							<text
								style="display: inline-block;position: absolute;left: 220rpx;top: 120rpx;">{{goodMessage}}</text>
							<uni-icons type="closeempty" size="20" @click="close2"
								style="position: absolute;right: 60rpx;top: 20rpx;"></uni-icons>
						</view>
						<!-- 选择 -->
						<view>
							<text style="display: block;margin: 10rpx 0;">产品</text>
							<uni-data-checkbox v-model="value" :localdata="range" @change="change(value)" mode="tag"
								selectedTextColor="#ff5934" style="margin-left: 20rpx;"></uni-data-checkbox>
							<text style="display: block;margin: 10rpx 0;">版本</text>
							<uni-data-checkbox v-model="value1" :localdata="range1" @change="change1(value1)" mode="tag"
								selectedTextColor="#ff5934" style="margin-left: 20rpx;"></uni-data-checkbox>
							<text style="display: block;margin: 10rpx 0;">颜色</text>
							<uni-data-checkbox v-model="value2" :localdata="range2" @change="change2(value2)" mode="tag"
								selectedTextColor="#ff5934" style="margin-left: 20rpx;"></uni-data-checkbox>
							<text style="display: inline-block;margin: 10rpx 0;">购买数量</text>
							<view class="" style="display: inline-block;width: 220rpx;float: right;">
								<uni-number-box @change="change4"></uni-number-box>
							</view>
							<text style="display: block;margin: 10rpx 0;">小米服务</text>
							<uni-data-checkbox v-model="value3" :localdata="range3" @change="change3(value3)" mode="tag"
								selectedTextColor="#ff5934" style="margin-left: 20rpx;"></uni-data-checkbox>
						</view>
					</view>
					<!-- 底部按钮 -->
					<view class="" style="width: 100%;position: fixed;bottom: 0;left: 0;background-color: #fff;">
						<button type="default"
							style="display: inline-block;width: 50vw;
						background-color: #fdcf00;border-top-left-radius: 50rpx;border-bottom-left-radius: 50rpx;color: #fff;">加入购物车</button>
						<button type="default" style="display: inline-block;width: 50vw;background-color: #FC6858;
						border-top-right-radius: 50rpx;border-bottom-right-radius: 50rpx;color: #fff;" @click="buy">立即购买</button>
					</view>
				</view>
			</view>
		</uni-popup>
		<!-- 地址 -->
		<view class="" @click="toAddress" style="height: 80rpx;">
			<text style="width: 100rpx;line-height: 80rpx;display: inline-block;margin-left: 20rpx;">送至
			</text><text>{{address}}</text>
		</view>
		<view class="" style="width: 100vw;height: 140rpx;">
			<text style="display: block;text-align: center;">-------------到底了----------</text>
		</view>
		<!-- 底部导航 -->
		<view class="" style="width: 100%;position: fixed;bottom: 0;left: 0;">
			<uni-goods-nav :fill="true" :options="options" :buttonGroup="buttonGroup" @click="onClick"
				@buttonClick="buttonClick" />
		</view>
	</view>
</template>

<script>
	const response = {
		"swiperImages": [{
				"id": 0,
				"src": "../../static/detailImages/detailImage1.jpg"
			},
			{
				"id": 1,
				"src": "../../static/detailImages/detailImage2.jpg"
			},
			{
				"id": 2,
				"src": "../../static/detailImages/detailImage3.jpg"
			}
		],
		"describe": {
			"title": "Redmi Note 11 Pro系列",
			"smallTitle": "至高优惠200元，活动到手价1599元起	",
			"data": [{
					"id": 0,
					"text": "1【金刚级大电量】5160mAh大电池+67W闪充"
				},
				{
					"id": 1,
					"text": "2【屏幕一眼惊艳】三星AMOLED屏幕+120Hz高刷"
				},
				{
					"id": 2,
					"text": "3【音质一声沉浸】JBL对称式立体声，小金刚史上最强音"
				}
			]
		},
		"icons": [{
				"id": 0,
				"src": "../../static/detailIcons/detailIcons1.png",
				"name": "CPU",
				"text": "天玑920"
			},
			{
				"id": 1,
				"src": "../../static/detailIcons/detailIcons2.png",
				"name": "三摄像头",
				"text": "10800万像素+800万像素+200万像素"
			},
			{
				"id": 2,
				"src": "../../static/detailIcons/detailIcons3.png",
				"name": "超大屏",
				"text": "6.67英寸"
			},
			{
				"id": 3,
				"src": "../../static/detailIcons/detailIcons4.png",
				"name": "屏幕分辨率",
				"text": "2400x1080 FHD+"
			},
			{
				"id": 4,
				"src": "../../static/detailIcons/detailIcons5.png",
				"name": "极速畅玩",
				"text": "最高8GB"
			},
			{
				"id": 5,
				"src": "../../static/detailIcons/detailIcons6.png",
				"name": "存储容量",
				"text": "最高256GB"
			},
			{
				"id": 6,
				"src": "../../static/detailIcons/detailIcons7.png",
				"name": "普通厚度",
				"text": "8.34mm"
			},
			{
				"id": 7,
				"src": "../../static/detailIcons/detailIcons8.png",
				"name": "超长待机",
				"text": "5160mAh"
			},
			{
				"id": 8,
				"src": "../../static/detailIcons/detailIcons9.png",
				"name": "运营商网络",
				"text": "双模5G全网通"
			},
			{
				"id": 9,
				"src": "../../static/detailIcons/detailIcons10.png",
				"name": "网络模式",
				"text": "双卡双待"
			}
		]
	}
	export default {
		data() {
			return {
				data: [],
				current: 1,
				scrollInto: '',
				options: [{
					icon: 'headphones',
					text: '客服'
				}, {
					icon: 'shop',
					text: '店铺',
					info: 2,
					infoBackgroundColor: '#007aff',
					infoColor: "red"
				}, {
					icon: 'cart',
					text: '购物车',
					info: 2
				}],
				buttonGroup: [{
						text: '加入购物车',
						backgroundColor: '#ff0000',
						color: '#fff'
					},
					{
						text: '立即购买',
						backgroundColor: '#ffa200',
						color: '#fff'
					}
				],
				range: [{
					"value": 0,
					"text": "Redmi Note 11 Pro"
				}, {
					"value": 1,
					"text": "Redmi Note 11 Pro+"
				}],
				range1: [{
					"value": 0,
					"text": "6GB+128GB"
				}, {
					"value": 1,
					"text": "8GB+128GB"
				}, {
					"value": 2,
					"text": "8GB+256GB"
				}],
				range2: [{
						"value": 0,
						"text": "浅梦星河"
					}, {
						"value": 1,
						"text": "神秘黑境"
					},
					{
						"value": 2,
						"text": "时光静紫"
					}, {
						"value": 3,
						"text": "迷雾森林"
					}
				],
				range3: [{
					"value": 0,
					"text": "意外保障服务199"
				}, {
					"value": 1,
					"text": "碎屏保障服务129"
				}],
				value: 0,
				value1: 0,
				value2: 0,
				value3: '',
				goodMessage:'',
				goodMessage2:'',
				value4:1,
				address:''
			}
		},
		methods: {
			changeSwiper(e) {
				this.current = e.detail.current + 1
			},
			back() {
				uni.navigateBack({
					delta: 1
				})
			},
			open() {
				this.$refs.popup.open('buttom')
			},
			close() {
				this.$refs.popup.close()
			},
			open2() {
				this.$refs.popup2.open('buttom')
			},
			close2() {
				this.$refs.popup2.close()
			},
			onClick(e) {
				uni.showToast({
					title: `点击${e.content.text}`,
					icon: 'none'
				})
			},
			buttonClick(e) {
				console.log(e)
				this.options[2].info++
			},
			change(e){
				let x=this.range[e].text;
				this.value=e;
				this.goodMessage=x+' '+this.range1[this.value1].text+' '+this.range2[this.value2].text;
			},
			change1(e){
				let x=this.range1[e].text;
				this.value1=e;
				this.goodMessage=this.range[this.value].text+' '+x+' '+this.range2[this.value2].text;
			},
			change2(e){
				let x=this.range2[e].text;
				this.value2=e;
				this.goodMessage=this.range[this.value].text+' '+this.range1[this.value1].text+' '+x;
			},
			change3(e){
				let x=this.range3[e].text;
				this.value3=e;
				this.goodMessage2=this.goodMessage+' '+x;
			},
			change4(e){
				this.value4=e
			},
			buy(){
				this.$refs.popup2.close();
				this.goodMessage2=this.goodMessage+'x'+this.value4
				
			},
			toAddress(){
				uni.navigateTo({
					url:'../adress/adress'
				})
			}
		},
		onLoad(option) {
			console.log(option);
			this.data = response;
		}
	}
</script>

<style>
	/deep/ .uni-popup .uni-popup__wrapper {
		width: 100vw;
		height: 1020rpx;

	}
</style>
