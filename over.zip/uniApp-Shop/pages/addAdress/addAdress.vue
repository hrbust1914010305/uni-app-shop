<template>
	<view>
		<!-- 数据填写 -->
		<uni-forms style="width: 90vw;margin: 0 auto;" :modelValue="formData" ref="form">
			<uni-forms-item label="姓名" name="name" style="height: 70rpx;line-height: 60rpx;">
				<uni-easyinput type="text" v-model="formData.name"></uni-easyinput>
			</uni-forms-item>
			<uni-forms-item label="联系方式" name="phone" style="height: 70rpx;line-height: 60rpx;">
				<uni-easyinput type="text" v-model="formData.phone"></uni-easyinput>
			</uni-forms-item>
			<uni-forms-item label="地址" name="address" style="height: 70rpx;line-height: 60rpx;">
				<pickerAddress style="width:100% ;height: 72rpx;border: #ddd 2rpx solid;" @change="change">{{address}}
				</pickerAddress>
			</uni-forms-item>
		</uni-forms>

		<button @click="submit" style="background-color: #FC6858;border-radius: 50rpx;margin-top: 20rpx;">确定</button>
	</view>
</template>

<script>
	import pickerAddress from '../../components/wangding-pickerAddress/wangding-pickerAddress.vue'
	export default {
		components: {
			pickerAddress
		},
		data() {
			return {
				address: '',
				formData: {
					name: '',
					phone: '',
					address: ''
				}
			}
		},
		onLoad() {

		},
		methods: {
			change(data) {
				this.address = data.data.join('')
				this.formData.address=this.address;
			},
			submit() {
				this.$refs.form.validate().then(res => {
					this.formData.name=res.name;
					this.formData.phone=res.phone;
					uni.navigateTo({
						url:"../adress/adress?name="+this.formData.name+"&phone="+this.formData.phone+"&address="+this.formData.address
					})
				}).catch(err => {
					console.log('表单错误信息：', err);
				})
			}
		}
	}
</script>

<style>

</style>
