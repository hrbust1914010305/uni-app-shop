<template>
	<view>
		<!-- 用户信息展示 -->
		<view class="" style="width: 100vw;height: 600rpx;">
			<view class="" style="width: 300rpx;height: 300rpx;border-radius: 50%;margin: 0 auto;">
				<image src="../../static/goodsList-images/goodsList-image1.jpg" mode=""
				style="width: 300rpx;height: 300rpx;border-radius: 50%;"></image>
			</view>
			<text style="color: #FC6858;display: block;text-align: center;">登录|注册</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
