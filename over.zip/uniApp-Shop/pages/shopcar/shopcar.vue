<template>
	<view>
		<uni-nav-bar title="购物车" leftIcon="left" rightIcon="search" @clickLeft="back" @clickRight="search"></uni-nav-bar>
		<!-- 订单列表 -->
		<view class="" style="width: 100vw;height: 180rpx;background-color: #ccc;">
			<label class="radio" style="height: 180rpx;line-height: 180rpx;margin-left: 20rpx;">
				<radio :checked="edit" @click="changeEdit"/><text></text>
			</label>
			<view class="" style="display: inline-block;position: absolute;">
				<image src="../../static/categotyImages/List2-9.png" mode="" style="width: 180rpx;height: 180rpx;">
				</image>
			</view>
			<view class="" style="height: 180rpx;width: 64vw;position: absolute;display: inline-block;right: 0;">
				<view class="" style="width: 64vw;height: 120rpx;">
					<text style="display: block;width: 64vw;height: 80rpx;">dadassda</text>
					<text>售价:￥451</text>
				</view>
				<view class="">
					<uni-number-box></uni-number-box>
					<uni-icons type="trash" size="20" style="position: absolute;right: 0;top: 120rpx;"></uni-icons>
				</view>
			</view>
		</view>
		<!-- 底部按钮 -->
		<view class="" style="width: 100vw;height: 120rpx;position: fixed;bottom: 100rpx;">
			<view class="" style="width: 40vw;height: 120rpx;display: inline-block;position: relative;top: -24rpx;">
				<text style="display: block;width:40vw;height: 40rpx;">共1件，金额:</text>
				<text style="display: block;width: 40vw;height: 80rpx;line-height: 80rpx;
				font-size: 50rpx;color: #FC6858;">262626<span style="color: #000000;font-size: 25rpx">元</span></text>
			</view>
			<button type="default" style="width: 30vw;height: 120rpx;display: inline-block;line-height: 120rpx;"
				@click="toCategory">继续购物</button>
			<button type="default"
				style="width: 30vw;height: 120rpx;display: inline-block;line-height: 120rpx;">去结算</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				edit:false
			}
		},
		methods: {
			toCategory() {
				uni.navigateTo({
					url: "../category/category"
				})
			},
			changeEdit(e){
				this.edit=!this.edit;
				if(this.edit===true){
					console.log('false')
				}
			},
			back(){
				uni.switchTab({
					url:"../category/category"
				})
			},
			search(){
				uni.navigateTo({
					url:"../search/search"
				})
			}
		},
		onLoad() {
			// console.log('App Launch')
			// uni.hideTabBar({})
		}
	}
</script>

<style>

</style>
