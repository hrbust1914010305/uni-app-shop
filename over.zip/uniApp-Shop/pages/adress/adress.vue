<template>
	<view>
		<!-- 地址展示 -->
		<view class="" v-for="(item,index) in Address" :key="index">
			<text style="display: inline-block;height: 60rpx;width: 70vw;">{{item.name}}</text>
			<text style="display: inline-block;height: 60rpx;width: 70vw;">{{item.address}}</text>
			<view class="" style="width: 30vw;display: inline-block;height: 120rpx;position: absolute;top: 0;">
				<button type="default" style="width: 30vw;height: 60rpx;position: absolute;top: 0;line-height: 60rpx;"
					@click="toDetail">选择</button>、
				<button type="default"
					style="width: 30vw;height: 60rpx;position: absolute;top: 60rpx;line-height: 60rpx;">删除</button>
			</view>
		</view>
		<!-- 添加地址 -->
		<view class="" style="width: 100vw;height: 120rpx;background-color: #FC6858;position: fixed;bottom: 0;border-radius: 50rpx;
		text-align: center;line-height: 120rpx;" @click="toAddresss">
			<text style="font-size: 50rpx;color: #fff;" @change="change">添加地址</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				Address: []
			}
		},
		onLoad(options) {
			let response = [];
			response[0] = options.name;
			response[1] = options.phone;
			response[2] = options.address;

			let object = {
				id: this.Address.length,
				name: response[0],
				phone: response[1],
				address: response[2]
			}

			this.Address.push(object);
		},
		onReady() {



		},
		methods: {
			toAddresss() {
				uni.navigateTo({
					url: "../addAdress/addAdress"
				})
			},
			toDetail() {
				uni.navigateTo({
					url: "../detail/detail?address=" + this.Address[0].address
				})
			}
		}
	}
</script>

<style>

</style>
