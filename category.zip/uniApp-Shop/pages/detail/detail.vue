<template>
	<view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		},
		onLoad(option) {
			console.log(option.id)
		}
	}
</script>

<style>

</style>
