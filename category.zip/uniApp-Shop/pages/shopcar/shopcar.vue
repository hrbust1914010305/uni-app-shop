<template>
	<view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
.box1{
	width: 100vw;
	height:200rpx;
	background-color: #007AFF;
}

.box2{
	width: 100vw;
	height: 1200rpx;
	background-color: #18BC37;
}
</style>
