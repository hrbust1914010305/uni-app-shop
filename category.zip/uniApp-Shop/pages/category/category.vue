<template>
	<view class="content">
		<!-- 顶部搜索 -->
		<view class="top" @click="toSearch">
			<input type="text" value="" placeholder="搜索商品名称" />
			<view class="search-icon">
				<uni-icons type="search" size="30"></uni-icons>
			</view>
		</view>
		<!-- 左侧导航栏-->
		<view class="leftBar">
			<scroll-view class="goodsList" scroll-y="true" :scroll-into-view="scrollInto">
				<view class="listItem" v-for="(item,index) in leftBar.leftBar" :key="index" :id="'tab-'+index"
					@click="changeTab(index)" :class="{line :tabIndex === index}">{{item.text}}</view>
			</scroll-view>
		</view>
		<!-- 右侧展示区 -->
		<!-- <view class="rightShow"> -->
		<swiper class="rightShow" :current="tabIndex" vertical="true">
			<swiper-item class="goodShow" v-for="(item,index) in leftBar.rightShow" :key="index">
				<!-- 推荐页 -->
				<template class="mainSection" v-if="item.type==='recommend'">
					<view class="img" @click="toDetail('header')">
						<image src="../../static/categotyImages/category1.png" mode=""
							style="width: calc(100vw - 200rpx);height: 160rpx;"></image>
					</view>
					<text style="display: inline-block;height: 60rpx;line-height: 60rpx;margin-top: 20rpx;">精选推荐</text>
					<!-- 产品列表 -->
					<list class="list">
						<li v-for="(Item,index) in item.listImages" :key="index" @click="toDetail(Item.id)">
							<view class="section">
								<image :src="Item.src" style="width: 140rpx;height: 140rpx;"></image>
							</view>
							<view class="text">
								{{Item.text}}
							</view>
							<view class="price">
								￥ {{Item.price}}
							</view>
						</li>
					</list>
					<!-- 配件 -->
					<uni-grid :column="4" >
						<view class="boxItem" v-for="(Item,index) in item.listImages2" @click="toDetail(Item.id)"
							style="width: 154rpx;margin: 10rpx;height: 154rpx;">
							<view class="img2" style="width: 104rpx;height: 104rpx;margin: 4rpx auto;">
								<image :src="Item.src" mode=""
									style="width: 108rpx;height: 108rpx;"></image>
							</view>
							<text style="display: block;text-align: center;font-size: 20rpx;">{{Item.text}}</text>
						</view>
					</uni-grid>
				</template>
				<!-- 小米手机页 -->
				<template v-else-if="item.type==='XiaomiPhone'">
					<view>{{item.text}}</view>
				</template>
				<!-- 其他 -->
				<template v-else>
					<view>{{item.text}}</view>
				</template>
			</swiper-item>
		</swiper>
		<!-- </view> -->
	</view>
</template>

<script>
	const response = {
		"leftBar": [{
				"id": 0,
				"text": "推荐"
			},
			{
				"id": 1,
				"text": "Xiaomi手机"
			},
			{
				"id": 2,
				"text": "Redmi手机"
			},
			{
				"id": 3,
				"text": "游戏手机"
			},
			{
				"id": 4,
				"text": "电脑平板"
			},
			{
				"id": 5,
				"text": "智能穿戴"
			},
			{
				"id": 6,
				"text": "电视"
			},
			{
				"id": 7,
				"text": "大家电"
			},
			{
				"id": 8,
				"text": "小家电"
			},
			{
				"id": 9,
				"text": "智能家居"
			},
			{
				"id": 10,
				"text": "户外出行"
			},
			{
				"id": 11,
				"text": "日用百货"
			},
			{
				"id": 12,
				"text": "儿童用品"
			},
			{
				"id": 13,
				"text": "有品精选"
			},
			{
				"id": 14,
				"text": "小米服务"
			}
		],
		"rightShow": [{
				"id": 0,
				"text": "推荐",
				"type": "recommend",
				"listImages": [{
						"id": 0,
						"src": "../../static/categotyImages/list1.png",
						"text": "米家电水壶1S",
						"price": "149"
					},
					{
						"id": 1,
						"src": "../../static/categotyImages/list2.png",
						"text": "小米米家液晶小黑板 存储版",
						"price": "349"
					},
					{
						"id": 2,
						"src": "../../static/categotyImages/list3.png",
						"text": "Redmi Note 10 5G",
						"price": "1099 起"
					}
				],
				"listImages2": [{
						"id": 0,
						"text": "台灯",
						"src": "../../static/categotyImages/List2-1.png"
					},
					{
						"id": 1,
						"text": "净水器",
						"src": "../../static/categotyImages/List2-2.png"
					},
					{
						"id": 2,
						"text": "窗帘",
						"src": "../../static/categotyImages/List2-3.png"
					},
					{
						"id": 3,
						"text": "加湿器",
						"src": "../../static/categotyImages/List2-4.png"
					},
					{
						"id": 4,
						"text": "口腔护理",
						"src": "../../static/categotyImages/List2-5.png"
					},
					{
						"id": 5,
						"text": "微醺烤",
						"src": "../../static/categotyImages/List2-6.png"
					},
					{
						"id": 6,
						"text": "小米Air 2 SE",
						"src": "../../static/categotyImages/List2-7.png"
					},
					{
						"id": 7,
						"text": "Redmi 手表",
						"src": "../../static/categotyImages/List2-8.png"
					},
					{
						"id": 8,
						"text": "Note 9",
						"src": "../../static/categotyImages/List2-9.png"
					},
					{
						"id": 9,
						"text": "烘洗一体机",
						"src": "../../static/categotyImages/List2-10.png"
					},
					{
						"id": 10,
						"text": "插座",
						"src": "../../static/categotyImages/List2-11.png"
					},
					{
						"id": 11,
						"text": "日用文具",
						"src": "../../static/categotyImages/List2-12.png"
					}
				]
			},
			{
				"id": 1,
				"text": "Xiaomi手机",
				"type": "XiaomiPhone"
			},
			{
				"id": 2,
				"text": "Redmi手机",
				"type": "RedmiPhone"
			},
			{
				"id": 3,
				"text": "游戏手机",
				"type": "gamephone"
			},
			{
				"id": 4,
				"text": "电脑平板",
				"type": "computer"
			},
			{
				"id": 5,
				"text": "智能穿戴",
				"type": "cloth"
			},
			{
				"id": 6,
				"text": "电视",
				"type": "TV"
			},
			{
				"id": 7,
				"text": "大家电",
				"type": "big"
			},
			{
				"id": 8,
				"text": "小家电",
				"type": "small"
			},
			{
				"id": 9,
				"text": "智能家居",
				"type": "Alhome"
			},
			{
				"id": 10,
				"text": "户外出行",
				"type": "out"
			},
			{
				"id": 11,
				"text": "日用百货",
				"type": "dayGoods"
			},
			{
				"id": 12,
				"text": "儿童用品",
				"type": "child"
			},
			{
				"id": 13,
				"text": "有品精选",
				"type": "goodSelect"
			},
			{
				"id": 14,
				"text": "小米服务",
				"type": "XiaomiServer"
			}
		]
	}
	export default {
		data() {
			return {
				leftBar: [],
				tabIndex: 0,
				scrollInto: ''
			}
		},
		methods: {
			toSearch() {
				uni.navigateTo({
					url: "../search/search"
				})
			},
			changeTab(index) {
				if (this.index === index) {
					return;
				}
				this.tabIndex = index;
				this.scrollInto = 'tab-' + index;
				// 下方tab-content 中的数据加载
			},
			toDetail(value){
				uni.navigateTo({
					url:"../detail/detail?id="+value
				})
			}
		},
		onLoad() {
			this.leftBar = response
		}
	}
</script>

<style>
	* {
		list-style: none;
	}

	.top {
		width: 100vw;
		height: 100rpx;
		position: fixed;
		z-index: 9;
		top: 0;
		bottom: 0;
	}

	.top input {
		width: calc(96vw - 100rpx);
		height: 80rpx;
		margin: 10rpx 2vw;
		background-color: #ddd;
		border-radius: 50rpx;
		padding-left: 100rpx;
	}

	.top .search-icon {
		position: relative;
		top: -80rpx;
		left: 40rpx;

	}

	.leftBar {
		display: inline-block;
		width: 160rpx;
		height: calc(100vh - 210rpx);
		margin-top: 110rpx;
	}

	.goodsList {
		display: inline-block;
		width: 160rpx;
		height: calc(100vh - 210rpx);
	}

	.listItem {
		width: 160rpx;
		height: 100rpx;
		line-height: 100rpx;
		text-align: center;
		font-size: 20rpx;
	}

	.line {
		padding-left: 8rpx;
		border-left: 8rpx solid #FC6858;
		background-color: #ddd;
	}

	.rightShow {
		display: inline-block;
		width: calc(100vw - 200rpx);
		height: calc(100vh - 200rpx);
		margin-left: 20rpx;
	}

	.goodShow {
		display: inline-block;
		width: calc(100vw - 200rpx);
		height: calc(100vh - 200rpx);
		margin-left: 20rpx;
		overflow: auto;
	}

	.img {
		width: calc(100vw - 200rpx);
		height: 160rpx;
	}

	.mainSection {
		width: calc(100vw - 160rpx);
		height: calc(100vh - 700rpx);
	}

	.list {
		width: calc(100vw - 220rpx);
	}

	.list li {
		height: 160rpx;
		width: calc(100vw - 220rpx);
		background-color: #EDEDED;
		border-radius: 20rpx;
		margin: 10rpx 0;
	}

	.section {
		display: inline-block;
		width: 140rpx;
		height: 140rpx;
		margin: 10rpx 20rpx 10rpx 10rpx;
	}

	.text {
		display: inline-block;
		height: 60rpx;
		width: 340rpx;
		position: relative;
		top: -80rpx;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
		line-height: 60rpx;
	}

	.price {
		display: inline-block;
		height: 60rpx;
		width: 340rpx;
		position: relative;
		top: -80rpx;
		left: 168rpx;
		line-height: 60rpx;
	}
</style>
