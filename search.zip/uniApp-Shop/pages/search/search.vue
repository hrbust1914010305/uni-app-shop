<template>
	<view>
		<!-- 顶部导航 -->
		<uni-nav-bar leftWidth="50rpx" rightWidth="50rpx" height="60rpx" backgroundColor="#f2f2f2">
			<!-- 左侧返回 -->
			<view slot="left">
				<uni-icons type="left" size="28" @click="back"></uni-icons>
			</view>
			<!-- 中间搜索 -->
			<uni-search-bar placeholder="例如:苹果" cancelButton="none" @confirm="search" @clear="clear"
				v-model="searchText">
			</uni-search-bar>
			<!-- 右侧搜索 -->
			<view slot="right">
				<uni-icons type="search" size="28" @click="searchTo"></uni-icons>
			</view>
		</uni-nav-bar>
		<!-- 搜索历史 -->
		<uni-group v-if="searchHistory.length>0" title="搜索历史">
			<view v-for="item in searchHistory" :key="item.id" class="tag">
				<uni-tag :text="item.text" circle="true"></uni-tag>
			</view>
		</uni-group>
		<!-- 删除图标 -->
		<uni-icons v-if="searchHistory.length>0" type="trash" size="26" class="delete" @click="open"></uni-icons>
		<!-- 弹框 -->
		<uni-popup ref="popup" type="dialog">
			<uni-popup-dialog mode="base" title="是否全部删除搜索历史?" @close="close" @confirm="confirm"></uni-popup-dialog>
		</uni-popup>
		<!-- 搜索发现 -->
		<uni-group title="搜索发现">
			<view class="box" v-for="(item,index) in findSearch" :key="index" @click="searchA(item.title)">
				{{item.title}}
			</view>
		</uni-group>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// 搜索发现的数据
				findSearch: [{
						id: 0,
						title: '全部商品'
					},
					{
						id: 1,
						title: '小米手机'
					},
					{
						id: 2,
						title: '红米'
					},
					{
						id: 3,
						title: '洗衣机'
					},
					{
						id: 4,
						title: '耳机'
					},
					{
						id: 5,
						title: '小米平板5 Pro'
					},
					{
						id: 6,
						title: '电视'
					},
					{
						id: 7,
						title: '黑鲨'
					}
				],
				//搜索框内容
				searchText: '',
				//搜索历史
				searchHistory: []
			}
		},
		methods: {
			searchTo() {
				console.log("searchTo", this.searchText);
				//传递 this.searchText 的值到后台获取数据

				this.searchText = '';
			},
			search(e) {
				this.searchText = e.value;
				let i = this.searchHistory.length;
				let tempDate = {
					id: i,
					text: e.value
				};
				this.searchHistory.push(tempDate);
				console.log("search", this.searchText);
				//传递 this.searchText 的值到后台获取数据

				this.searchText = '';
			},
			clear(e) {
				this.searchText = "";
			},
			searchA(value) {
				console.log(value);
				//传递 value 的值到后台获取数据
			},
			open() {
				this.$refs.popup.open('center');
			},
			close() {
				this.$refs.popup.close();
			},
			confirm() {
				let i = this.searchHistory.length;
				while (i != 0) {
					this.searchHistory.pop();
					i--;
				}
				this.$refs.popup.close();
			},
			back() {
				uni.switchTab({
					url: "../index/index"
				})
			}
		}
	}
</script>

<style>
	* {
		margin: 0;
		padding: 0;
	}

	/deep/ .uni-searchbar {
		padding: 0;
		height: 60rpx;
		width: calc(100vw - 100rpx);
	}

	/deep/ .uni-searchbar__box {
		height: 61rpx;
	}

	.box {
		width: 42vw;
		margin: 10rpx 2vw;
		height: 60rpx;
		display: inline-block;
		line-height: 60rpx;
		text-align: left;
	}

	/deep/ .uni-group__title {
		background-color: #fff;
	}

	/deep/ .uni-group__title span {
		font-size: 32rpx;
		color: #3c3c3c;
		font-weight: bold;
	}

	/deep/ .uni-group__content {
		padding-left: 60rpx;
		padding-top: 0;
		padding-right: 0;
		padding-bottom: 0;
	}

	/deep/ .uni-tag {
		color: #000000;
		background-color: rgba(0, 0, 0, .04);
		border-style: none;
	}

	.tag {
		display: inline-block;
		padding: 5rpx 10rpx 5rpx 0;
	}

	.delete {
		position: absolute;
		right: 20rpx;
		top: 96rpx;
	}
</style>
