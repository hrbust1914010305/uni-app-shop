<template>
	<view class="content">
		<!-- 头部标题框 -->
		<uni-nav-bar shadow="false" border="false" height="60rpx" style="width: 100%;" leftWidth="54rpx" rightWidth="54rpx" backgroundColor="#f2f2f2">
			<!-- 左侧商标 -->
			<view slot="left" style="width: 50rpx;height: 60rpx;line-height: 60rpx;">
				<image src="../../static/image/xiaomi.png" mode="" style="width:50rpx;height:32rpx;"></image>
			</view>
			<!-- 中间搜索框 -->
			<input placeholder="例如:苹果" @click="change"
			 style="padding: 0;width:calc(100vw - 108rpx);height: 60rpx; padding-left: 60rpx;border: 1px solid #e5e5e5;background-color: #fff;">
			 <uni-icons type="search" size="25" style="position: absolute;height: 60rpx; line-height: 60rpx;"></uni-icons>
			</input>
			<!-- 右侧我的图标 -->
			<view slot="right"
				style="width: 50rpx;height: 60rpx;line-height: 60rpx;text-align: center;">
				<uni-icons type="person" size="28" @click="toUser"></uni-icons>
			</view>
		</uni-nav-bar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: 'Hello',
				searchValue: ''
			}
		},
		onLoad() {

		},
		methods: {
			toUser(){
				console.log("ds")
				uni.switchTab({
					url:'../user/user'
				})
			},
			change(){
				uni.navigateTo({
					url:'../search/search'
				})
			},
			
		}
	}
</script>

<style>
	* {
		margin: 0;
		padding: 0;
	}
</style>
